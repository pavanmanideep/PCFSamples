/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./SingaporeNricValidator/index.ts"
/*!*****************************************!*\
  !*** ./SingaporeNricValidator/index.ts ***!
  \*****************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Singapore: () => (/* binding */ Singapore)\n/* harmony export */ });\nclass Singapore {\n  constructor() {\n    this.handleInputChange = () => {\n      var normalized = this.normalizeInput(this.inputElement.value);\n      if (this.inputElement.value !== normalized) {\n        this.inputElement.value = normalized;\n      }\n      this.currentValue = normalized;\n      this.renderValidationMessage();\n      this.notifyOutputChanged();\n    };\n    this.notifyOutputChanged = () => {\n      return;\n    };\n    this.currentValue = \"\";\n    this.inputElement = document.createElement(\"input\");\n    this.messageElement = document.createElement(\"div\");\n  }\n  /**\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\n   * Data-set values are not initialized here, use updateView.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\n   */\n  init(context, notifyOutputChanged, state, container) {\n    this.notifyOutputChanged = notifyOutputChanged;\n    this.currentValue = this.normalizeInput(context.parameters.nricValue.raw);\n    this.inputElement = document.createElement(\"input\");\n    this.inputElement.type = \"text\";\n    this.inputElement.placeholder = \"e.g. S1234567D\";\n    this.inputElement.maxLength = 9;\n    this.inputElement.value = this.currentValue;\n    this.inputElement.style.width = \"100%\";\n    this.inputElement.style.boxSizing = \"border-box\";\n    this.inputElement.style.padding = \"8px\";\n    this.messageElement = document.createElement(\"div\");\n    this.messageElement.style.marginTop = \"6px\";\n    this.messageElement.style.fontSize = \"12px\";\n    this.inputElement.addEventListener(\"input\", this.handleInputChange);\n    container.appendChild(this.inputElement);\n    container.appendChild(this.messageElement);\n    this.renderValidationMessage();\n  }\n  /**\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\n   */\n  updateView(context) {\n    var latestValue = this.normalizeInput(context.parameters.nricValue.raw);\n    if (latestValue !== this.currentValue) {\n      this.currentValue = latestValue;\n      this.inputElement.value = latestValue;\n    }\n    this.renderValidationMessage();\n  }\n  /**\n   * It is called by the framework prior to a control receiving new data.\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as \"bound\" or \"output\"\n   */\n  getOutputs() {\n    return {\n      nricValue: this.currentValue\n    };\n  }\n  /**\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\n   */\n  destroy() {\n    this.inputElement.removeEventListener(\"input\", this.handleInputChange);\n  }\n  normalizeInput(value) {\n    return (value !== null && value !== void 0 ? value : \"\").toUpperCase().replace(/[^A-Z0-9]/g, \"\").slice(0, 9);\n  }\n  renderValidationMessage() {\n    var validation = this.validateNric(this.currentValue);\n    this.messageElement.textContent = validation.message;\n    this.messageElement.style.color = validation.isValid ? \"#107C10\" : \"#A4262C\";\n  }\n  validateNric(value) {\n    if (!value) {\n      return {\n        isValid: false,\n        message: \"Enter NRIC/FIN.\"\n      };\n    }\n    var normalized = value.toUpperCase();\n    var formatRegex = /^[STFGM]\\d{7}[A-Z]$/;\n    if (!formatRegex.test(normalized)) {\n      return {\n        isValid: false,\n        message: \"Please enter a valid Singapore NRIC Number\"\n      };\n    }\n    var prefix = normalized.charAt(0);\n    var digits = normalized.substring(1, 8).split(\"\").map(digit => parseInt(digit, 10));\n    var weights = [2, 7, 6, 5, 4, 3, 2];\n    var sum = 0;\n    for (var index = 0; index < weights.length; index++) {\n      sum += digits[index] * weights[index];\n    }\n    if (prefix === \"T\" || prefix === \"G\") {\n      sum += 4;\n    }\n    if (prefix === \"M\") {\n      sum += 3;\n    }\n    var remainder = sum % 11;\n    var citizenSequence = \"JZIHGFEDCBA\";\n    var foreignSequence = \"XWUTRQPNMLK\";\n    var expectedChecksum = prefix === \"S\" || prefix === \"T\" ? citizenSequence.charAt(remainder) : foreignSequence.charAt(remainder);\n    var actualChecksum = normalized.charAt(8);\n    if (actualChecksum !== expectedChecksum) {\n      return {\n        isValid: false,\n        message: \"Please enter a valid Singapore NRIC Number\"\n      };\n    }\n    return {\n      isValid: true,\n      message: \"Valid NRIC/FIN.\"\n    };\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./SingaporeNricValidator/index.ts?\n}");

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./SingaporeNricValidator/index.ts"](0,__webpack_exports__,__webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('NRIC.Singapore', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.Singapore);
} else {
	var NRIC = NRIC || {};
	NRIC.Singapore = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.Singapore;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}